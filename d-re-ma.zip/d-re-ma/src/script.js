function sk(){ document.getElementById('k').src ="https://cdn.discordapp.com/attachments/1077578035982782475/1178066823384678502/1-1.png?ex=6574cb3a&is=6562563a&hm=acfc1d3d04fecd7af96c5bb2873b1bd38344471e3e75552af0d3ed4418cc268f&" ; 
setInterval(sk,0);
 }

function skinfo(){ document.write("")
  
}

